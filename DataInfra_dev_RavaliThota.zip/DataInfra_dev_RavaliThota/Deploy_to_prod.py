# Databricks notebook source
import base64
import requests
import json

DATABRICKS_INSTANCE = "https://adb-3579770537136251.11.azuredatabricks.net/"  


DATABRICKS_TOKEN = "dapie61928ad0f0e32fb2e9425a1814841a5-3"

# Source Notebooks Paths
source_paths = [
    "/Workspace/Repos/ravalitht11@gmail.com/DataInfra_dev_RavaliThota/etl/Landing_to_Bronze_Layer",
    "/Workspace/Repos/ravalitht11@gmail.com/DataInfra_dev_RavaliThota/etl/Bronze_to_Silver_Layer",
    "/Workspace/Repos/ravalitht11@gmail.com/DataInfra_dev_RavaliThota/etl/Silver_to_Gold_Layer"
]

# Target folder in Workspace
target_base_path = "/Workspace/Repos/ravalitht11@gmail.com/DataInfra_prod_RavaliThota/"

# Headers for API
HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}"
}

# export notebook
def export_notebook(source_path):
    export_url = f"{DATABRICKS_INSTANCE}/api/2.0/workspace/export"
    payload = {
        "path": source_path,
        "format": "SOURCE" 
    }
    response = requests.get(export_url, headers=HEADERS, params=payload)
    if response.status_code == 200:
        return response.content
    else:
        raise Exception(f"Export failed: {response.text}")

# import notebook
def import_notebook(content_base64, target_path):
    import_url = f"{DATABRICKS_INSTANCE}/api/2.0/workspace/import"
    payload = {
        "path": target_path,
        "format": "SOURCE",
        "language": "PYTHON",
        "content": base64.b64encode(content_base64).decode('utf-8'),
        "overwrite": True
    }
    response = requests.post(import_url, headers=HEADERS, json=payload)
    if response.status_code == 200:
        print(f"✅ Deployed to {target_path}")
    else:
        raise Exception(f"Import failed: {response.text}")

# Deploy all notebooks
for source_path in source_paths:
    notebook_name = source_path.split("/")[-1]
    target_path = target_base_path + notebook_name
    print(f"Deploying {notebook_name}...")

    content = export_notebook(source_path)
    import_notebook(content, target_path)

print("🚀 Deployment to Production completed successfully!")
