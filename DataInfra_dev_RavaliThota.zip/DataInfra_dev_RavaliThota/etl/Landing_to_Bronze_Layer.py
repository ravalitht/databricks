# Databricks notebook source
# MAGIC %md
# MAGIC #Create Bronze tables

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create airports Bronze table

# COMMAND ----------

# Storage configurations
storage_account_name = "databrickssaravali"
storage_account_key = "zcAizRPdQHB+HyMQS5T/8HyNBZp0+rgCwzHy1K0L6AAVoHgIzyOiR/DF1WP0MQe3VIAMZP9AUojT+AStyBaSDg=="

# Build the wasbs URL fro filepath
file_path = f"wasbs://landing@{storage_account_name}.blob.core.windows.net/airports.csv"

# Read landing data into dataframe and save as Delta Bronze table
def bronze_airports_ingestion(file_path):
    df_bronze_airports = spark.read.format("csv") \
         .option("header", "true") \
         .option("inferSchema", "true") \
         .option("fs.azure.account.key." + storage_account_name + ".blob.core.windows.net", storage_account_key) \
         .load(file_path)
    df_bronze_airports.write.format("delta").mode("overwrite").saveAsTable("bronze_airports")
    print("Bronze Ingestion completed - Data Cleansed and Ingested into airports table")


#Landing to Bronze Ingestion
bronze_airports_ingestion(file_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create countries Bronze table

# COMMAND ----------

# Storage configurations
storage_account_name = "databrickssaravali"
storage_account_key = "zcAizRPdQHB+HyMQS5T/8HyNBZp0+rgCwzHy1K0L6AAVoHgIzyOiR/DF1WP0MQe3VIAMZP9AUojT+AStyBaSDg=="

# Build the wasbs URL fro filepath
file_path = f"wasbs://landing@{storage_account_name}.blob.core.windows.net/countries.csv"

# Read landing data into dataframe and save as Delta Bronze table
def bronze_countries_ingestion(file_path):
    df_bronze_countries = spark.read.format("csv") \
         .option("header", "true") \
         .option("inferSchema", "true") \
         .option("fs.azure.account.key." + storage_account_name + ".blob.core.windows.net", storage_account_key) \
         .load(file_path)
    df_bronze_countries.write.format("delta").mode("overwrite").saveAsTable("bronze_countries")
    print("Bronze Ingestion completed - Data Cleansed and Ingested into countries table")


#Landing to Bronze Ingestion
bronze_countries_ingestion(file_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create runways Bronze table

# COMMAND ----------

# Storage configuration
storage_account_name = "databrickssaravali"
storage_account_key = "zcAizRPdQHB+HyMQS5T/8HyNBZp0+rgCwzHy1K0L6AAVoHgIzyOiR/DF1WP0MQe3VIAMZP9AUojT+AStyBaSDg=="

# Build the wasbs URL for filepath
file_path = f"wasbs://landing@{storage_account_name}.blob.core.windows.net/runways.csv"

# Read landing data into dataframe and save as Delta Bronze table
def bronze_runways_ingestion(file_path):
    df_bronze_runways = spark.read.format("csv") \
         .option("header", "true") \
         .option("inferSchema", "true") \
         .option("fs.azure.account.key." + storage_account_name + ".blob.core.windows.net", storage_account_key) \
         .load(file_path)

    df_bronze_runways.write.format("delta").mode("overwrite").saveAsTable("bronze_runways")
    print("Bronze Ingestion completed - Data Cleansed and Ingested into bronze_runways table")


#Landing to Bronze Ingestion
bronze_runways_ingestion(file_path)