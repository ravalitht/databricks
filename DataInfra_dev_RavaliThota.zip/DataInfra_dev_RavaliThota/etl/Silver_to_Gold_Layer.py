# Databricks notebook source
# MAGIC %md
# MAGIC #Create Gold Tables

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create Longest and Shortest runways of airports Gold table

# COMMAND ----------

#Read Silver tables
def read_silver_airports():
    return spark.read.table("silver_airports")

def read_silver_countries():
    return spark.read.table("silver_countries")

def read_silver_runways():
    return spark.read.table("silver_runways")

#Longest and Shortest Runways of each airport in each country
def longestShortestRunways(silver_airports):
    spark.sql("""
        CREATE OR REPLACE TABLE gold_longest_shortest_runways
        USING DELTA
        PARTITIONED BY (country)
        AS
            WITH longest_runways AS (
                SELECT 
                    ac.id AS airport_id,
                    ac.name AS airport,
                    co.name AS country,
                    r.length_ft AS runway_length,
                    r.width_ft AS runway_width
                FROM silver_airports ac
                INNER JOIN silver_runways r ON ac.id = r.airport_ref
                INNER JOIN silver_countries co ON ac.iso_country = co.code
                WHERE ac.type IN ('small_airport', 'medium_airport', 'large_airport')
                AND r.length_ft = (SELECT MAX(length_ft) FROM silver_runways ru WHERE ru.airport_ref = ac.id)
            ),
            shortest_runways AS (
                SELECT 
                    ac.id AS airport_id,
                    r.length_ft AS runway_length,
                    r.width_ft AS runway_width
                FROM silver_airports ac
                INNER JOIN silver_runways r ON ac.id = r.airport_ref
                WHERE ac.type IN ('small_airport', 'medium_airport', 'large_airport')
                AND r.length_ft = (SELECT MIN(length_ft) FROM silver_runways ry WHERE ry.airport_ref = ac.id)
            )
        SELECT 
            lr.country,
            lr.airport,
            lr.runway_length AS longest_runway_length,
            lr.runway_width AS longest_runway_width,
            sr.runway_length AS shortest_runway_length,
            sr.runway_width AS shortest_runway_width
        FROM longest_runways lr
        INNER JOIN shortest_runways sr ON lr.airport_id = sr.airport_id
    """)
    print("Gold Ingestion completed - Data Transformed and Ingested into gold_longest_shortest_runways table")


#Silver to Gold Ingestion
silver_airports = read_silver_airports()
longestShortestRunways(silver_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create Top 3 countries with highest count of airports Gold table

# COMMAND ----------

#Read Silver table
def read_silver_airports():
    return spark.read.table("silver_airports")

def read_silver_countries():
    return spark.read.table("silver_countries")

#Top 3 countries with highest count of airports
def top3countrieswithairports(silver_airports,silver_countries):
    spark.sql("""
        CREATE OR REPLACE TABLE top3_gold_country_airport_counts
        USING DELTA
        SELECT 
        co.name as Country,
        COUNT(ai.iso_country) as AirportsCount
        FROM silver_airports ai
        INNER JOIN silver_countries co ON ai.iso_country = co.code
        WHERE ai.type IN ('small_airport', 'medium_airport', 'large_airport')
        GROUP BY co.name
        ORDER BY COUNT(ai.iso_country) DESC
        LIMIT 3
    """)
    print("Gold Ingestion completed - Data Transformed and Ingested into Top 3 countries with highest count of airports table")


#Silver to Gold Ingestion
silver_airports = read_silver_airports()
silver_countries = read_silver_countries()
top3countrieswithairports(silver_airports,silver_countries)


# COMMAND ----------

# MAGIC %md
# MAGIC ##Create Bottom 10 countries with lowest count of airports Gold table

# COMMAND ----------

#Read Silver table
def read_silver_airports():
    return spark.read.table("silver_airports")

def read_silver_countries():
    return spark.read.table("silver_countries")

#Bottom 10 countries with highest count of airports
def bottom10countrieswithairports(silver_airports,silver_countries):
    spark.sql("""
        CREATE OR REPLACE TABLE bottom10_gold_country_airport_counts
        USING DELTA
        SELECT 
        co.name as Country,
        COUNT(ai.iso_country) as AirportsCount
        FROM silver_airports ai
        INNER JOIN silver_countries co ON ai.iso_country = co.code
        WHERE ai.type IN ('small_airport', 'medium_airport', 'large_airport')
        GROUP BY co.name
        ORDER BY COUNT(ai.iso_country) ASC
        LIMIT 10
    """)
    print("Gold Ingestion completed - Data Transformed and Ingested into Bottom 10 countries with highest count of airports table")


#Silver to Gold Ingestion
silver_airports = read_silver_airports()
silver_countries = read_silver_countries()
df_bottom10 = bottom10countrieswithairports(silver_airports,silver_countries)
print(df_bottom10)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create airports Gold table

# COMMAND ----------

#Read silver table
def read_silver_airports():
    return spark.read.table("silver_airports")

# Read silver data into dataframe and save as Delta gold table
def gold_airports_ingestion(silver_airports):
    df_gold_airports = silver_airports
    # Save as Delta Gold table
    df_gold_airports.write.format("delta").mode("overwrite").saveAsTable("gold_airports")

    print("Gold Ingestion completed - Data Cleansed and Ingested into gold_airports table")
    

#Silver to Gold Ingestion
silver_airports = read_silver_airports()
gold_airports_ingestion(silver_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create countries Gold table

# COMMAND ----------

#Read silver table
def read_silver_countries():
    return spark.read.table("silver_countries")

# Read silver data into dataframe and save as Delta Gold table
def gold_countries_ingestion(silver_countries):
    df_gold_countries = silver_countries
    # Save as Delta Gold table
    df_gold_countries.write.format("delta").mode("overwrite").saveAsTable("gold_countries")

    print("Gold Ingestion completed - Data Cleansed and Ingested into gold_countries table")
    

#Silver to Gold Ingestion
silver_countries = read_silver_countries()
gold_countries_ingestion(silver_countries)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create runways Gold table

# COMMAND ----------

#Read silver table
def read_silver_runways():
    return spark.read.table("silver_runways")

# Read silver data into dataframe and save as Delta Gold table
def gold_runways_ingestion(silver_runways):
    df_gold_runways = silver_runways
    # Save as Delta Gold table
    df_gold_runways.write.format("delta").mode("overwrite").saveAsTable("gold_runways")

    print("Gold Ingestion completed - Data Cleansed and Ingested into gold_runways table")
    

#Silver to Gold Ingestion
silver_runways = read_silver_runways()
gold_runways_ingestion(silver_runways)