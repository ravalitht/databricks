# Databricks notebook source
# MAGIC %md
# MAGIC #Create Silver tables

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create airports Silver table

# COMMAND ----------

#Read bronze table
def read_bronze_airports():
    return spark.read.table("bronze_airports")

# Read bronze data into dataframe and save as Delta Silver table
def silver_airports_ingestion(bronze_airports):
    df_silver_airports = bronze_airports

    #Data Cleansing Transformations
    Cleansing_columns = ["id","ident"]
    df_silver_airports = df_silver_airports.dropDuplicates(Cleansing_columns)
    df_silver_airports = df_silver_airports.dropna(how="any", subset=Cleansing_columns)

    # Save as Delta Silver table
    df_silver_airports.write.format("delta").mode("overwrite").saveAsTable("silver_airports")

    print("Silver Ingestion completed - Data Cleansed and Ingested into silver_airports table")
    

#Bronze to Silver Ingestion
bronze_airports = read_bronze_airports()
silver_airports_ingestion(bronze_airports)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create countries Silver table

# COMMAND ----------

#Read bronze table
def read_bronze_countries():
    return spark.read.table("bronze_countries")

# Read bronze data into dataframe and save as Delta Silver table
def silver_countries_ingestion(bronze_countries):
    df_silver_countries = bronze_countries

    #Data Cleansing Transformations
    Cleansing_columns = ["code","id"]
    df_silver_countries = df_silver_countries.dropDuplicates(Cleansing_columns)
    df_silver_countries = df_silver_countries.dropna(how="any", subset=Cleansing_columns)

    # Save as Delta Silver table
    df_silver_countries.write.format("delta").mode("overwrite").saveAsTable("silver_countries")

    print("Silver Ingestion completed - Data Cleansed and Ingested into silver_countries table")


#Bronze to Silver Ingestion
bronze_countries = read_bronze_countries()
silver_countries_ingestion(bronze_countries)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Create runways Silver table

# COMMAND ----------

#Read bronze table
def read_bronze_runways():
    return spark.read.table("bronze_runways")

# Read bronze data into dataframe and save as Delta Silver table
def silver_runways_ingestion(bronze_runways):
    df_silver_runways = bronze_runways

    #Data Cleansing Transformations
    Cleansing_columns = ["id"]
    df_silver_runways = df_silver_runways.dropDuplicates(Cleansing_columns)
    df_silver_runways = df_silver_runways.dropna(how="any", subset=Cleansing_columns)

    # Save as Delta Silver table
    df_silver_runways.write.format("delta").mode("overwrite").saveAsTable("silver_runways")

    print("Silver Ingestion completed - Data Cleansed and Ingested into silver_runways table")


#Bronze to Silver Ingestion
bronze_runways = read_bronze_runways()
silver_runways_ingestion(bronze_runways)