#Test1 - Verifies ingestion to airports bronze table is not broken
df_bronze_airports = spark.read.table("bronze_airports")
assert df_bronze_airports.count() > 0, "Bronze airports table has no rows!"

#Test2 - Verifies ingestion to countries bronze table is not broken
df_bronze_countries = spark.read.table("bronze_countries")
assert df_bronze_countries.count() > 0, "Bronze countries table has no rows!"

#Test3 - Verifies ingestion to runways bronze table is not broken
df_bronze_runways = spark.read.table("bronze_runways")
assert df_bronze_runways.count() > 0, "Bronze runways table has no rows!"