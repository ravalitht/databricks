#Test1 - Verifies null values in aiport id
df_silver_airports = spark.read.table("silver_airports")
null_airport_id = df_silver_airports.filter(df_silver_airports.id.isNull()).count()
assert null_airport_id == 0, "Silver table has null airport id!"

#Test2 - Verifies null values in aiport ident
df_silver_airports = spark.read.table("silver_airports")
null_airport_ident = df_silver_airports.filter(df_silver_airports.ident.isNull()).count()
assert null_airport_id == 0, "Silver table has null airport ident!"

#Test3 - Verifies duplicate values in aiport id
from pyspark.sql.functions import col
duplicate_count = df_silver_airports.groupBy("id").count().filter(col("count") > 1).count()
assert duplicate_count == 0, "Duplicates arport ids found in Silver layer!"