#Test1 - Verifies ingestion to longestshortestrunways gold table is not broken
df_gold_longestshortestrunways = spark.read.table("gold_longest_shortest_runways")
assert df_gold_longestshortestrunways.count() > 0, "Bronze longest shortest runways table has no rows!"

#Test2 - Verifies ingestion to Top3countrieswithairports gold table is not broken
df_gold_top3countriesaiportscount = spark.read.table("top3_gold_country_airport_counts")
assert df_gold_top3countriesaiportscount.count() > 0, "Bronze longest shortest runways table has no rows!"

#Test3 - Verifies ingestion to Bottom10countrieswithairports gold table is not broken
df_gold_bottom10countriesaiportscount = spark.read.table("bottom10_gold_country_airport_counts")
assert df_gold_bottom10countriesaiportscount.count() > 0, "Bronze longest shortest runways table has no rows!"