# DataInfra SRE Readme

## Introduction:
This project demonstrates the implementation of an end-to-end ETL (Extract, Transform, Load) pipeline following the Medallion Architecture (Landing → Bronze → Silver → Gold).
The goal is to ingest raw data, cleanse and standardize it, apply business logic transformations, and prepare datasets for data consumers.
## Approach:
![Approach](./1.PNG)

## ETL Pipeline Approach:
The following approach was adopted to build the ETL pipeline using the Medallion Architecture:
### •	Landing Layer:
This layer ingests raw data as-is into the storage environment without any transformations.
### •	Bronze Layer:
Raw data from the Landing Layer is ingested into the Bronze Layer. No transformations are applied at this stage; the data is stored in its original form to ensure traceability.
### •	Silver Layer:
Data from the Bronze Layer undergoes data cleansing and standardization.
At this stage, key quality checks are performed, including:
o	Handling and removing duplicates.
o	Addressing null values in unique identifier columns across airports, runways, and countries datasets.
### •	Gold Layer:
Gold layer, Here all business logics and transformations are applied. This is the ready to use data for Data consumers
## Project Structure/Steps :
![Project Structure]
(./2.PNG)

1.	Upload csv files to Landing container under Storage account
2.	Read landing data to Dataframe from blob storage and Write as table into SQL in Delta format. Tables created in Bronze layer are  bronze_airports, bronze_countries, bronze_runways
3.	Read bronze data to Dataframe and handled duplicates and nulls on unique columns. Data cleansing is done in this layer. Tables created silver_airports, silver_countries, silver_runways
4.	Read data from Silver layer and apply transformations and business logics to the data. Create delta tables and insert the transformed data into delta tables of Gold layer. Tables created longestshortestrunways, top3countrieswithhighestairports, bottom10countrieswithairports, gold_airports, gold_countries, gold_runways
5.	This data in Gold layer is ready to consume by Data Consumers
6.	Create Unit tests for running tests on the tables created 
7.	Create Jobs and orchestrate the workflow in pipeline
8.	Schedule the jobs by creating schedules

## Data Quality and Testing
Basic unit tests are incorporated to ensure data reliability at each stage:
•	Row Count Validation: Ensuring no data loss during ingestion.
•	Null Value Checks: Critical columns are validated for nulls.
•	Duplicate Detection: Ensuring data uniqueness.

## CI/CD
 ![CICD](./3.png)
•	Created CI/CD pipeline in Data bricks workflows

•	Run Notebooks Bronze, Silver and Gold -> Run Tests-> If all tests are passed->Automatically deploy to prod folder.

![](./4.png)

## Schedules:
Used pipeline triggers to trigger the pipeline everyday at 8 AM CET.

![Schedules](./5.png)
 
## How to Run the Project
1.	Scheduled Jobs triggers the pipeline at the time of schedule
2.	Pipeline gets triggered and notebooks start running as per orchestration
				Runs the Bronze ETL notebook to ingest data from Landing to Bronze.
				Runs the Silver ETL notebook to cleanse data from Bronze.
				Runs the Gold ETL notebook to apply transformations and create final tables
3.	Tables are created or updated based during execution
4.	Unit tests are run after the pipeline execution
		a.	Runs Bronze ETL unit test to check the tables ingestion
		b.	Runs Silver ETL unit test to check the Nulls and duplicates do not exist
		c.	Runs Gold ETL unit test to  verify the tables ingestion
5.	Can trigger the pipeline manually by jobs->select Airports_Data_Infra_batch_job_daily->Run now.

## Assumptions:
1.	Only airport types such as small airports, medium airports, gold airports are considered as airport. Excluded others like heliports, seaports etc
2.	Airports longest and shortest runways are determined by length_ft alone
3.	Countries is uniquely identified by iso_Country
4.	Runways is uniquely identified by runway_id
5.	Airports is uniquely identified by id, ident

## Challenges:
Width Matching
	When finding longest and shortest runways, ensuring correct width is matched to correct length was tricky. Simple aggregation did not do the job.

## Improvements:
1.	Incremental Refresh and Read data from data source directly:
Schema Evolution – Detect and merge schema changes if future csv files evolve
2.	Clusters for distributed execution and scaling
3.	Unity Catalog for Data Governance

## Notes:
1.	Built completely serverless – can be scaled by adjusting cluster size
2.	Data is stored in Delta format in each step
3.	Each layer improves data quality and adds more structure
4.	CI/CD has been built from Databricks workflows, added yaml file to demonstrate my knowledge on yaml syntax.
